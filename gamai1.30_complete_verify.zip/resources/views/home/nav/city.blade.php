<div class="category_detail category_city" style="">
    <input type="text" class="city_select form-control">
    <div class="" style="padding-top: 8px;">
        <a href="javascript:void(0);" class="btn btn-success btn-reset" style="float:right;">Reset</a>
    </div>
</div>